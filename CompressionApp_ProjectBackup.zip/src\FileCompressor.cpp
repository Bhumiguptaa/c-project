#include "FileCompressor.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <unordered_map>
#include <map>

bool FileCompressor::compressFile(const std::string& inputPath, const std::string& outputPath) {
    std::ifstream inFile(inputPath, std::ios::binary | std::ios::ate);
    if (!inFile) {
        std::cerr << "Failed to open input file: " << inputPath << std::endl;
        return false;
    }

    std::streamsize size = inFile.tellg();
    inFile.seekg(0, std::ios::beg);
    
    std::vector<char> buffer(size);
    if (!inFile.read(buffer.data(), size)) {
        std::cerr << "Failed to read input file." << std::endl;
        return false;
    }

    // LZW Compression
    std::unordered_map<std::string, int> dictionary;
    for (int i = 0; i < 256; i++) {
        dictionary[std::string(1, char(i))] = i;
    }

    std::string w = "";
    std::vector<int> compressedData;
    int dictSize = 256;

    for (char c : buffer) {
        std::string wc = w + c;
        if (dictionary.count(wc)) {
            w = wc;
        } else {
            compressedData.push_back(dictionary[w]);
            if (dictSize < 65536) { // Limit dictionary size to 16 bits
                dictionary[wc] = dictSize++;
            }
            w = std::string(1, c);
        }
    }
    if (!w.empty()) {
        compressedData.push_back(dictionary[w]);
    }

    // Write output
    std::ofstream outFile(outputPath, std::ios::binary);
    if (!outFile) {
        std::cerr << "Failed to open output file: " << outputPath << std::endl;
        return false;
    }

    // Header: original file size (to cross-check if needed)
    uint32_t originalSize = static_cast<uint32_t>(size);
    outFile.write(reinterpret_cast<const char*>(&originalSize), sizeof(originalSize));

    for (int code : compressedData) {
        uint16_t outCode = static_cast<uint16_t>(code);
        outFile.write(reinterpret_cast<const char*>(&outCode), sizeof(outCode));
    }

    std::streamsize outSize = outFile.tellp();
    std::cout << "Successfully compressed file to: " << outputPath 
              << " (Original: " << size << " bytes, Compressed: " << outSize << " bytes)" << std::endl;
    return true;
}

bool FileCompressor::decompressFile(const std::string& inputPath, const std::string& outputPath) {
    std::ifstream inFile(inputPath, std::ios::binary);
    if (!inFile) {
        std::cerr << "Failed to open input file: " << inputPath << std::endl;
        return false;
    }

    uint32_t originalSize;
    if (!inFile.read(reinterpret_cast<char*>(&originalSize), sizeof(originalSize))) {
        return false;
    }

    std::vector<int> compressedData;
    uint16_t code;
    while (inFile.read(reinterpret_cast<char*>(&code), sizeof(code))) {
        compressedData.push_back(code);
    }

    if (compressedData.empty()) {
        return false;
    }

    // LZW Decompression
    std::map<int, std::string> dictionary;
    for (int i = 0; i < 256; i++) {
        dictionary[i] = std::string(1, char(i));
    }

    int dictSize = 256;
    std::string w(1, static_cast<char>(compressedData[0]));
    std::string result = w;
    std::string entry;

    for (size_t i = 1; i < compressedData.size(); i++) {
        int k = compressedData[i];
        if (dictionary.count(k)) {
            entry = dictionary[k];
        } else if (k == dictSize) {
            entry = w + w[0];
        } else {
            std::cerr << "Decompression error" << std::endl;
            return false;
        }

        result += entry;

        if (dictSize < 65536) {
            dictionary[dictSize++] = w + entry[0];
        }
        w = entry;
    }

    std::ofstream outFile(outputPath, std::ios::binary);
    if (!outFile) {
        std::cerr << "Failed to open output file: " << outputPath << std::endl;
        return false;
    }
    
    outFile.write(result.c_str(), result.size());

    std::cout << "Successfully decompressed file to: " << outputPath << std::endl;
    return true;
}
