#include "ImageCompressor.h"
#include <iostream>

#define STB_IMAGE_IMPLEMENTATION
#include "../external/stb_image.h"

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "../external/stb_image_write.h"

bool ImageCompressor::compressImage(const std::string& inputPath, const std::string& outputPath, int quality) {
    int width, height, channels;
    // Load image
    unsigned char* img = stbi_load(inputPath.c_str(), &width, &height, &channels, 0);
    if (img == nullptr) {
        std::cerr << "Failed to load image: " << inputPath << std::endl;
        return false;
    }

    std::cout << "Loaded image: " << width << "x" << height << " with " << channels << " channels." << std::endl;

    // Write it as JPEG with defined quality
    int result = stbi_write_jpg(outputPath.c_str(), width, height, channels, img, quality);
    stbi_image_free(img);

    if (result == 0) {
        std::cerr << "Failed to write compressed image: " << outputPath << std::endl;
        return false;
    }

    std::cout << "Successfully compressed image to: " << outputPath << " (Quality: " << quality << ")" << std::endl;
    return true;
}
