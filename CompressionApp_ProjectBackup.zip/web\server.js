const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.static('public'));

fs.mkdirSync('uploads', { recursive: true });

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'),
    filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});

const upload = multer({ storage });
const exePath = path.resolve(__dirname, '../compressor.exe');

app.post('/api/compress-file', upload.single('file'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

    const inputPath = req.file.path;
    const outputPath = inputPath + '.bin';
    
    execFile(exePath, ['file', 'compress', inputPath, outputPath], (error, stdout, stderr) => {
        if (error) {
            console.error(`Compression error: ${stderr}`);
            return res.status(500).json({ error: 'Failed to compress file' });
        }
        
        res.download(outputPath, 'compressed_file.bin', (err) => {
            // Clean up files
            try { fs.unlinkSync(inputPath); } catch(e){}
            try { fs.unlinkSync(outputPath); } catch(e){}
        });
    });
});

app.post('/api/compress-image', upload.single('image'), (req, res) => {
    if (!req.file) return res.status(400).json({ error: 'No image uploaded' });

    const inputPath = req.file.path;
    const outputPath = inputPath + '.jpg';
    const quality = req.body.quality || '50';

    execFile(exePath, ['image', inputPath, outputPath, quality], (error, stdout, stderr) => {
        if (error) {
            console.error(`Image compression error: ${stderr}`);
            return res.status(500).json({ error: 'Failed to compress image' });
        }
        
        res.download(outputPath, 'compressed_image.jpg', (err) => {
            // Clean up files
            try { fs.unlinkSync(inputPath); } catch(e){}
            try { fs.unlinkSync(outputPath); } catch(e){}
        });
    });
});

app.listen(port, () => {
    console.log(`Server listening on http://localhost:${port}`);
});
