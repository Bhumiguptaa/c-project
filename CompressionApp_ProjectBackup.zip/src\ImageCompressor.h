#pragma once
#include <string>

class ImageCompressor {
public:
    // Compress an image by converting it to JPEG format with a specific quality (0-100)
    static bool compressImage(const std::string& inputPath, const std::string& outputPath, int quality = 50);
};
