#include <windows.h>
#include <commdlg.h>
#include <string>
#include "FileCompressor.h"
#include "ImageCompressor.h"

// Check if dialog libraries are included
#pragma comment(lib, "comdlg32.lib")

// Control Identifiers
#define ID_BROWSE_FILE_IN 101
#define ID_BROWSE_FILE_OUT 102
#define ID_COMPRESS_FILE 103
#define ID_DECOMPRESS_FILE 104

#define ID_BROWSE_IMG_IN 105
#define ID_BROWSE_IMG_OUT 106
#define ID_COMPRESS_IMG 107

#define ID_EDIT_FILE_IN 201
#define ID_EDIT_FILE_OUT 202
#define ID_EDIT_IMG_IN 203
#define ID_EDIT_IMG_OUT 204
#define ID_EDIT_IMG_QUAL 205

#define ID_STATUS_TEXT 301

// Global Variables
HWND hMainWnd;
HWND hEditFileIn, hEditFileOut;
HWND hEditImgIn, hEditImgOut, hEditImgQual;
HWND hStatus;

std::string GetTextFromHWND(HWND hwnd) {
    int len = GetWindowTextLength(hwnd);
    if (len == 0) return "";
    std::string text;
    text.resize(len);
    GetWindowTextA(hwnd, &text[0], len + 1);
    return text;
}

void SetStatus(const std::string& msg) {
    SetWindowTextA(hStatus, msg.c_str());
}

std::string OpenFileDialog(HWND hwndOwner, const char* filter) {
    OPENFILENAMEA ofn;
    char szFile[260] = { 0 };
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwndOwner;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = filter;
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
    if (GetOpenFileNameA(&ofn) == TRUE) {
        return std::string(ofn.lpstrFile);
    }
    return "";
}

std::string SaveFileDialog(HWND hwndOwner, const char* filter) {
    OPENFILENAMEA ofn;
    char szFile[260] = { 0 };
    ZeroMemory(&ofn, sizeof(ofn));
    ofn.lStructSize = sizeof(ofn);
    ofn.hwndOwner = hwndOwner;
    ofn.lpstrFile = szFile;
    ofn.nMaxFile = sizeof(szFile);
    ofn.lpstrFilter = filter;
    ofn.nFilterIndex = 1;
    ofn.lpstrFileTitle = NULL;
    ofn.nMaxFileTitle = 0;
    ofn.lpstrInitialDir = NULL;
    ofn.Flags = OFN_PATHMUSTEXIST | OFN_OVERWRITEPROMPT;

    if (GetSaveFileNameA(&ofn) == TRUE) {
        return std::string(ofn.lpstrFile);
    }
    return "";
}

// Helper callback for font setting
BOOL CALLBACK SetFontChildCallback(HWND child, LPARAM param) {
    SendMessage(child, WM_SETFONT, param, MAKELPARAM(TRUE, 0));
    return TRUE;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_CREATE: {
        // --- FILE COMPRESSION SECTION ---
        CreateWindowA("BUTTON", "File Compression", WS_VISIBLE | WS_CHILD | BS_GROUPBOX,
            10, 10, 460, 150, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Input File:", WS_VISIBLE | WS_CHILD, 20, 35, 80, 20, hwnd, NULL, NULL, NULL);
        hEditFileIn = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL,
            100, 35, 270, 20, hwnd, (HMENU)ID_EDIT_FILE_IN, NULL, NULL);
        CreateWindowA("BUTTON", "Browse...", WS_VISIBLE | WS_CHILD, 380, 35, 80, 20, hwnd, (HMENU)ID_BROWSE_FILE_IN, NULL, NULL);

        CreateWindowA("STATIC", "Output File:", WS_VISIBLE | WS_CHILD, 20, 65, 80, 20, hwnd, NULL, NULL, NULL);
        hEditFileOut = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL,
            100, 65, 270, 20, hwnd, (HMENU)ID_EDIT_FILE_OUT, NULL, NULL);
        CreateWindowA("BUTTON", "Browse...", WS_VISIBLE | WS_CHILD, 380, 65, 80, 20, hwnd, (HMENU)ID_BROWSE_FILE_OUT, NULL, NULL);

        CreateWindowA("BUTTON", "Compress File", WS_VISIBLE | WS_CHILD, 100, 105, 120, 30, hwnd, (HMENU)ID_COMPRESS_FILE, NULL, NULL);
        CreateWindowA("BUTTON", "Decompress File", WS_VISIBLE | WS_CHILD, 250, 105, 120, 30, hwnd, (HMENU)ID_DECOMPRESS_FILE, NULL, NULL);


        // --- IMAGE COMPRESSION SECTION ---
        CreateWindowA("BUTTON", "Image Compression (.jpg out)", WS_VISIBLE | WS_CHILD | BS_GROUPBOX,
            10, 170, 460, 180, hwnd, NULL, NULL, NULL);

        CreateWindowA("STATIC", "Input Image:", WS_VISIBLE | WS_CHILD, 20, 195, 80, 20, hwnd, NULL, NULL, NULL);
        hEditImgIn = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL,
            100, 195, 270, 20, hwnd, (HMENU)ID_EDIT_IMG_IN, NULL, NULL);
        CreateWindowA("BUTTON", "Browse...", WS_VISIBLE | WS_CHILD, 380, 195, 80, 20, hwnd, (HMENU)ID_BROWSE_IMG_IN, NULL, NULL);

        CreateWindowA("STATIC", "Output JPEG:", WS_VISIBLE | WS_CHILD, 20, 225, 80, 20, hwnd, NULL, NULL, NULL);
        hEditImgOut = CreateWindowA("EDIT", "", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_AUTOHSCROLL,
            100, 225, 270, 20, hwnd, (HMENU)ID_EDIT_IMG_OUT, NULL, NULL);
        CreateWindowA("BUTTON", "Browse...", WS_VISIBLE | WS_CHILD, 380, 225, 80, 20, hwnd, (HMENU)ID_BROWSE_IMG_OUT, NULL, NULL);

        CreateWindowA("STATIC", "Quality (0-100):", WS_VISIBLE | WS_CHILD, 20, 260, 100, 20, hwnd, NULL, NULL, NULL);
        hEditImgQual = CreateWindowA("EDIT", "50", WS_VISIBLE | WS_CHILD | WS_BORDER | ES_NUMBER,
            130, 260, 50, 20, hwnd, (HMENU)ID_EDIT_IMG_QUAL, NULL, NULL);

        CreateWindowA("BUTTON", "Compress Image", WS_VISIBLE | WS_CHILD, 100, 300, 270, 30, hwnd, (HMENU)ID_COMPRESS_IMG, NULL, NULL);

        // --- STATUS SECTION ---
        hStatus = CreateWindowA("STATIC", "Ready.", WS_VISIBLE | WS_CHILD | WS_BORDER,
            10, 370, 460, 30, hwnd, (HMENU)ID_STATUS_TEXT, NULL, NULL);

        // Set standard GUI font
        HFONT hFont = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
        SendMessage(hwnd, WM_SETFONT, (WPARAM)hFont, MAKELPARAM(TRUE, 0));
        EnumChildWindows(hwnd, SetFontChildCallback, (LPARAM)hFont);

        return 0;
    }

    case WM_COMMAND: {
        int id = LOWORD(wParam);
        switch (id) {
        case ID_BROWSE_FILE_IN: {
            std::string file = OpenFileDialog(hwnd, "All Files (*.*)\0*.*\0");
            if (!file.empty()) SetWindowTextA(hEditFileIn, file.c_str());
            break;
        }
        case ID_BROWSE_FILE_OUT: {
            std::string file = SaveFileDialog(hwnd, "LZW Compressed (*.bin)\0*.bin\0All Files (*.*)\0*.*\0");
            if (!file.empty()) SetWindowTextA(hEditFileOut, file.c_str());
            break;
        }
        case ID_COMPRESS_FILE: {
            std::string in = GetTextFromHWND(hEditFileIn);
            std::string out = GetTextFromHWND(hEditFileOut);
            if (in.empty() || out.empty()) {
                SetStatus("Please select both input and output files.");
                break;
            }
            SetStatus("Compressing file...");
            if (FileCompressor::compressFile(in, out)) {
                SetStatus("File successfully compressed to: " + out);
            } else {
                SetStatus("Failed to compress file. (Check console or permissions)");
            }
            break;
        }
        case ID_DECOMPRESS_FILE: {
            std::string in = GetTextFromHWND(hEditFileIn);
            std::string out = GetTextFromHWND(hEditFileOut);
            if (in.empty() || out.empty()) {
                SetStatus("Please select both input and output files.");
                break;
            }
            SetStatus("Decompressing file...");
            if (FileCompressor::decompressFile(in, out)) {
                SetStatus("File successfully decompressed to: " + out);
            } else {
                SetStatus("Failed to decompress file. Ensure it is a valid compressed .bin");
            }
            break;
        }

        case ID_BROWSE_IMG_IN: {
            std::string file = OpenFileDialog(hwnd, "Images (*.png;*.jpg;*.bmp;*.jpeg)\0*.png;*.jpg;*.bmp;*.jpeg\0All Files (*.*)\0*.*\0");
            if (!file.empty()) SetWindowTextA(hEditImgIn, file.c_str());
            break;
        }
        case ID_BROWSE_IMG_OUT: {
            std::string file = SaveFileDialog(hwnd, "JPEG Image (*.jpg)\0*.jpg\0");
            if (!file.empty()) SetWindowTextA(hEditImgOut, file.c_str());
            break;
        }
        case ID_COMPRESS_IMG: {
            std::string in = GetTextFromHWND(hEditImgIn);
            std::string out = GetTextFromHWND(hEditImgOut);
            std::string qualStr = GetTextFromHWND(hEditImgQual);

            if (in.empty() || out.empty()) {
                SetStatus("Please select both input and output image paths.");
                break;
            }
            int quality = 50;
            if (!qualStr.empty()) quality = std::stoi(qualStr);

            SetStatus("Compressing image...");
            if (ImageCompressor::compressImage(in, out, quality)) {
                SetStatus("Image successfully optimized & compressed as JPEG!");
            } else {
                SetStatus("Failed to compress image. (Image may be invalid)");
            }
            break;
        }
        }
        return 0;
    }

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    const char CLASS_NAME[] = "CompressorAppGUI";

    WNDCLASSA wc = { 0 };
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = CLASS_NAME;
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW);

    if (!RegisterClassA(&wc)) {
        MessageBoxA(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    hMainWnd = CreateWindowExA(
        0,
        CLASS_NAME,
        "Native C++ File & Image Compressor",
        WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX, // Non-resizable
        CW_USEDEFAULT, CW_USEDEFAULT, 500, 460,
        NULL, NULL, hInstance, NULL
    );

    if (hMainWnd == NULL) {
        MessageBoxA(NULL, "Window Creation Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    ShowWindow(hMainWnd, nCmdShow);
    UpdateWindow(hMainWnd);

    MSG msg = { 0 };
    while (GetMessage(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}
