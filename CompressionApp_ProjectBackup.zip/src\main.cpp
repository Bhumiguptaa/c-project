#include <iostream>
#include <string>
#include "FileCompressor.h"
#include "ImageCompressor.h"

void printUsage() {
    std::cout << "Usage:" << std::endl;
    std::cout << "  File Compression:" << std::endl;
    std::cout << "    compressor file compress <input_file> <output_file>" << std::endl;
    std::cout << "    compressor file decompress <input_file> <output_file>" << std::endl;
    std::cout << std::endl;
    std::cout << "  Image Compression:" << std::endl;
    std::cout << "    compressor image <input_image> <output_image.jpg> [quality (0-100), default: 50]" << std::endl;
}

int main(int argc, char* argv[]) {
    if (argc < 4) {
        printUsage();
        return 1;
    }

    std::string mode = argv[1];

    if (mode == "file") {
        if (argc < 5) {
            printUsage();
            return 1;
        }
        std::string action = argv[2];
        std::string input = argv[3];
        std::string output = argv[4];

        if (action == "compress") {
            FileCompressor::compressFile(input, output);
        } else if (action == "decompress") {
            FileCompressor::decompressFile(input, output);
        } else {
            std::cerr << "Unknown file action: " << action << std::endl;
            return 1;
        }
    } else if (mode == "image") {
        std::string input = argv[2];
        std::string output = argv[3];
        int quality = 50;
        
        if (argc >= 5) {
            quality = std::stoi(argv[4]);
        }
        
        ImageCompressor::compressImage(input, output, quality);
    } else {
        std::cerr << "Unknown mode: " << mode << std::endl;
        printUsage();
        return 1;
    }

    return 0;
}
