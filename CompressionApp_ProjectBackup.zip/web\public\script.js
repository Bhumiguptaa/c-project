// File Name Displays
document.getElementById('fileInput').addEventListener('change', function(e) {
    const name = e.target.files[0] ? e.target.files[0].name : "No file chosen";
    document.getElementById('fileNameDisplay').textContent = name;
});

document.getElementById('imageInput').addEventListener('change', function(e) {
    const name = e.target.files[0] ? e.target.files[0].name : "No image chosen";
    document.getElementById('imageNameDisplay').textContent = name;
});

// Quality Slider Sync
const qualityInput = document.getElementById('qualityInput');
const qualityVal = document.getElementById('qualityVal');
qualityInput.addEventListener('input', function() {
    qualityVal.textContent = this.value;
});

// Generic Fetch/Download logic
async function handleUpload(endpoint, formData, button, statusEl, originalName) {
    button.classList.add('loading');
    button.disabled = true;
    statusEl.textContent = "Processing native C++ logic...";
    statusEl.className = "status-msg";

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`Compression failed.`);
        }

        const blob = await response.blob();
        
        // Setup download link
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        // Generate nice downloaded name
        a.download = "compressed_" + originalName;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        
        statusEl.textContent = "Success! File Downloaded.";
    } catch (error) {
        statusEl.textContent = "Error: " + error.message;
        statusEl.className = "status-msg status-error";
    } finally {
        button.classList.remove('loading');
        button.disabled = false;
    }
}

// Form Handlers
document.getElementById('fileForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const fileInput = document.getElementById('fileInput');
    if (!fileInput.files[0]) return;

    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    const btn = this.querySelector('.action-btn');
    const status = document.getElementById('fileStatus');
    
    handleUpload('/api/compress-file', formData, btn, status, fileInput.files[0].name + '.bin');
});

document.getElementById('imageForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const imgInput = document.getElementById('imageInput');
    if (!imgInput.files[0]) return;

    const formData = new FormData();
    formData.append('image', imgInput.files[0]);
    formData.append('quality', qualityInput.value);

    const btn = this.querySelector('.action-btn');
    const status = document.getElementById('imgStatus');

    handleUpload('/api/compress-image', formData, btn, status, 'output.jpg');
});
